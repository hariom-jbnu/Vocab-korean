
import { ThemeType, ThemeColors } from './types';

// The provided SVG converted to a data URL for easy usage in <img> tags
const logoSvg = `<?xml version="1.0" encoding="utf-8"?><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55.7 38.9" style="enable-background:new 0 0 55.7 38.9" xml:space="preserve"><style type="text/css">.st0{fill:#FEFEFE;stroke:#CCCCCC;stroke-width:0.5;stroke-miterlimit:2.6131;} .st1{fill:#252422;} .st2{fill:none;stroke:#252422;stroke-width:1.6002;} .st3{fill:none;stroke:#FEFEFE;stroke-width:0.7999;} .st4{fill:#C62631;} .st5{fill:#303C70;}</style><g><path class="st0" d="M3.28,38.65h49.13c1.67,0,3.03-1.37,3.03-3.03V3.28c0-1.67-1.36-3.03-3.03-3.03H3.28 c-1.67,0-3.03,1.36-3.03,3.03v32.33C0.25,37.29,1.61,38.65,3.28,38.65L3.28,38.65z"/><path class="st1" d="M12.54,15.01l5.32-7.99L12.54,15.01L12.54,15.01z M10.54,13.68l5.33-7.99L10.54,13.68L10.54,13.68z M8.55,12.35l5.33-7.99L8.55,12.35L8.55,12.35z"/><path class="st2" d="M12.54,15.01l5.32-7.99 M10.54,13.68l5.33-7.99 M8.55,12.35l5.33-7.99"/><path class="st1" d="M41.83,34.54l5.33-7.99L41.83,34.54L41.83,34.54z M39.83,33.21l5.33-7.99L39.83,33.21L39.83,33.21z M37.83,31.88l5.33-7.99L37.83,31.88L37.83,31.88z"/><path class="st2" d="M41.83,34.54l5.33-7.99 M39.83,33.21l5.33-7.99 M37.83,31.88l5.33-7.99"/><line class="st3" x1="39.17" y1="26.99" x2="45.82" y2="31.43"/><path class="st4" d="M19.86,14.13c2.94-4.41,8.9-5.6,13.31-2.66c4.41,2.94,5.6,8.9,2.66,13.31c-2.94,4.41-8.9,5.6-13.31,2.66 C18.11,24.5,16.92,18.54,19.86,14.13L19.86,14.13z"/><path class="st5" d="M19.86,14.13c-1.47,2.21-0.87,5.19,1.33,6.66c2.21,1.47,5.19,0.87,6.66-1.33c1.47-2.21,4.45-2.8,6.66-1.33 c2.21,1.47,2.8,4.45,1.33,6.66c-2.94,4.41-8.9,5.6-13.31,2.66C18.11,24.5,16.92,18.54,19.86,14.13L19.86,14.13z"/><path class="st1" d="M17.86,31.88l-5.32-7.99L17.86,31.88L17.86,31.88z M15.87,33.21l-5.33-7.99L15.87,33.21L15.87,33.21z M13.87,34.54l-5.33-7.99L13.87,34.54L13.87,34.54z"/><path class="st2" d="M17.86,31.88l-5.32-7.99 M15.87,33.21l-5.33-7.99 M13.87,34.54l-5.33-7.99"/><path class="st1" d="M47.15,12.35l-5.33-7.99L47.15,12.35L47.15,12.35z M45.16,13.68l-5.33-7.99L45.16,13.68L45.16,13.68z M43.16,15.01l-5.33-7.99L43.16,15.01L43.16,15.01z"/><path class="st2" d="M47.15,12.35l-5.33-7.99 M45.16,13.68l-5.33-7.99 M43.16,15.01l-5.33-7.99"/><path class="st1" d="M43.49,9.02l2-1.33L43.49,9.02L43.49,9.02z M39.17,11.91l2.33-1.55L39.17,11.91L39.17,11.91z M12.21,29.88 l2-1.33L12.21,29.88L12.21,29.88z"/><path class="st3" d="M43.49,9.02l2-1.33 M39.17,11.91l2.33-1.55 M12.21,29.88l2-1.33"/></g></svg>`;

export const LOGO_PATH = `data:image/svg+xml;base64,${btoa(logoSvg)}`;
export const VOCAB_CSV_URL = 'data/ko_hi_en_vocab.csv';

export const CARD_PALETTE = [
  '#FFFFFF', '#F1F5F9', '#CBD5E1', // Whites/Grays
  '#FEF3C7', '#D1FAE5', '#DBEAFE', // Warm/Cool Pastels
  '#FCE7F3', '#EDE9FE', '#1E293B'  // Pinks/Purples/Dark Slate
];

export const THEMES: Record<ThemeType, ThemeColors> = {
  [ThemeType.TEAL]: {
    primary: '#005461',
    secondary: '#3BC1A8',
    accent: '#249E94',
    background: '#0C7779',
    text: '#FFFFFF',
    cardBg: '#FFFFFF'
  },
  [ThemeType.NAVY]: {
    primary: '#30364F',
    secondary: '#ACBAC4',
    accent: '#E1D9BC',
    background: '#F0F0DB',
    text: '#30364F',
    cardBg: '#FFFFFF'
  },
  [ThemeType.PINK]: {
    primary: '#222222',
    secondary: '#FA8112',
    accent: '#F5E7C6',
    background: '#FAF3E1',
    text: '#222222',
    cardBg: '#FFFFFF'
  }
};
